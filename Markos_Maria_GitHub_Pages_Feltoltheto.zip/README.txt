MARKOS MÁRIA — ONLINE PORTFÓLIÓ / GITHUB PAGES

A weboldalhoz az index.html és a Markos_Maria_Portfolio.pdf fájlt ugyanabba a GitHub-tárhelymappába kell feltölteni.
A .nojekyll fájlt is feltöltheted; GitHub Pageshez készült.

GitHub: New repository > Public > Create repository.
Add file > Upload files > a ZIP-ből kicsomagolt index.html és PDF (+ .nojekyll) > Commit changes.
Settings > Pages > Source: Deploy from a branch > Branch: main / (root) > Save.
Néhány perc után a link: https://FELHASZNALONEV.github.io/TARHELYNEV/

A weboldalon a demók külön szerver nélkül működnek, és a PDF ugyanarról a webcímről megnyitható.
Ne töltsd fel a Moodle .mbz mentését: csak ez a három webes fájl kerüljön nyilvánosságra.
